package com.pulse.phone

import android.Manifest
import android.app.role.RoleManager
import android.graphics.BitmapFactory
import android.provider.BlockedNumberContract
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.content.ContentValues
import android.provider.CallLog
import android.text.format.DateUtils
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

val BG = Color(0xFF0B0B14); val Card = Color(0x14FFFFFF); val Purple = Color(0xFF7C5CFF)
val Cyan = Color(0xFF22D3EE); val Green = Color(0xFF22C55E); val Mute = Color(0xFF9A9AB5)
val Grad = Brush.linearGradient(listOf(Purple, Cyan))
val AvColors = listOf(Color(0xFF7C5CFF), Color(0xFF22D3EE), Color(0xFFF43F5E), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFFEC4899), Color(0xFF3B82F6))

data class Contact(val name: String, val number: String, val id: String = "", val photo: String? = null)
data class Sms(val address: String, val body: String, val date: Long, val out: Boolean)

fun norm(s: String) = s.filter { it.isDigit() }.takeLast(10)

fun loadContacts(c: Context): List<Contact> = try {
    val out = mutableListOf<Contact>()
    c.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI),
        null, null, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
    )?.use { while (it.moveToNext()) out += Contact(it.getString(0) ?: "", it.getString(1) ?: "", it.getString(2) ?: "", it.getString(3)) }
    out.distinctBy { it.name + norm(it.number) }
} catch (e: SecurityException) { emptyList() }

fun loadSms(c: Context): List<Sms> = try {
    val out = mutableListOf<Sms>()
    c.contentResolver.query(
        Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "type"),
        null, null, "date DESC LIMIT 600"
    )?.use {
        while (it.moveToNext())
            out += Sms(it.getString(0) ?: "?", it.getString(1) ?: "", it.getLong(2), it.getInt(3) != 1)
    }
    out
} catch (e: SecurityException) { emptyList() }

fun sendSms(c: Context, to: String, body: String) {
    val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
    else @Suppress("DEPRECATION") SmsManager.getDefault()
    sm.sendMultipartTextMessage(to, null, sm.divideMessage(body), null, null)
    if (Telephony.Sms.getDefaultSmsPackage(c) == c.packageName)
        c.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
            put("address", to); put("body", body); put("date", System.currentTimeMillis())
        })
}

object Refresh { var tick by mutableIntStateOf(0) }
data class CallEntry(val number: String, val type: Int, val date: Long)

fun loadCalls(c: Context): List<CallEntry> = try {
    val out = mutableListOf<CallEntry>()
    c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf("number", "type", "date"), null, null, "date DESC LIMIT 200")
        ?.use { while (it.moveToNext()) out += CallEntry(it.getString(0) ?: "", it.getInt(1), it.getLong(2)) }
    out
} catch (e: SecurityException) { emptyList() }

fun roleIntent(c: Context, role: String): Intent? {
    val rm = c.getSystemService(RoleManager::class.java)
    return if (rm.isRoleAvailable(role) && !rm.isRoleHeld(role)) rm.createRequestRoleIntent(role) else null
}

fun placeCall(c: Context, n: String) {
    val ok = ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
    c.startActivity(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        val d = intent?.data
        val chat = if (d != null && d.scheme in listOf("sms", "smsto", "mms", "mmsto")) d.schemeSpecificPart else null
        val dial = if (d != null && d.scheme == "tel") d.schemeSpecificPart else null
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = BG, surface = BG)) { PulseApp(chat, dial) } }
    }
    override fun onResume() { super.onResume(); Refresh.tick++ }
}

@Composable fun PulseApp(startChat: String? = null, dial: String? = null) {
    val ctx = LocalContext.current
    var contacts by remember { mutableStateOf(listOf<Contact>()) }
    var sms by remember { mutableStateOf(listOf<Sms>()) }
    val perms = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALL_LOG, Manifest.permission.POST_NOTIFICATIONS)
    var calls by remember { mutableStateOf(listOf<CallEntry>()) }
    val reload = { contacts = loadContacts(ctx); Photos.map = contacts.filter { it.photo != null }.associate { it.name to it.photo!! }; sms = loadSms(ctx); calls = loadCalls(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { reload() }
    LaunchedEffect(Unit) { launcher.launch(perms) }
    val tick = Refresh.tick
    LaunchedEffect(tick) { reload() }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { Refresh.tick++ }
    val missing = remember(tick) { listOfNotNull(roleIntent(ctx, RoleManager.ROLE_DIALER), roleIntent(ctx, RoleManager.ROLE_SMS)) }
    var tab by remember { mutableIntStateOf(0) }
    var chat by remember { mutableStateOf(startChat) }
    val nameOf = { n: String -> contacts.firstOrNull { norm(it.number) == norm(n) }?.name ?: n }

    Box(Modifier.fillMaxSize().background(BG)) {
        Box(Modifier.fillMaxWidth().height(320.dp).background(Brush.verticalGradient(listOf(Purple.copy(.28f), Color.Transparent))))
        Scaffold(containerColor = Color.Transparent, bottomBar = {
            NavigationBar(containerColor = Color(0xFF14142A)) {
                listOf("Keypad" to Icons.Filled.Call, "Recents" to Icons.Filled.History, "Messages" to Icons.Filled.Email, "Contacts" to Icons.Filled.Person).forEachIndexed { i, (l, ic) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, l) }, label = { Text(l) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.White, indicatorColor = Purple, unselectedIconColor = Mute, unselectedTextColor = Mute, selectedTextColor = Color.White))
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                Column {
                    if (missing.isNotEmpty()) Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp)).background(Grad)
                        .clickable { roleLauncher.launch(missing.first()) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Make Pulse your default Phone & Messages app", color = Color.White, fontWeight = FontWeight.SemiBold)
                    }
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            0 -> Dialer(contacts, dial ?: "") { placeCall(ctx, it) }
                            1 -> Recents(calls, { n -> contacts.firstOrNull { norm(it.number) == norm(n) }?.name ?: n }) { placeCall(ctx, it) }
                            2 -> Threads(sms, nameOf) { chat = it }
                            else -> Contacts(contacts, { placeCall(ctx, it) }, { chat = it },
                                { id -> ctx.startActivity(Intent(Intent.ACTION_EDIT, Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, id))) },
                                { ctx.startActivity(Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)) })
                        }
                    }
                }
            }
        }
        chat?.let { addr ->
            BackHandler { chat = null }
            Chat(nameOf(addr), sms.filter { norm(it.address) == norm(addr) }.sortedBy { it.date }, { chat = null }) { body ->
                sendSms(ctx, addr, body)
                sms = listOf(Sms(addr, body, System.currentTimeMillis(), true)) + sms
            }
        }
    }
}

object Photos { var map by mutableStateOf(mapOf<String, String>()) }

@Composable fun Avatar(name: String, size: Int = 46) {
    val ctx = LocalContext.current
    val uri = Photos.map[name]
    val bmp = remember(uri) {
        uri?.let { try { ctx.contentResolver.openInputStream(Uri.parse(it))?.use { st -> BitmapFactory.decodeStream(st) }?.asImageBitmap() } catch (e: Exception) { null } }
    }
    Box(Modifier.size(size.dp).clip(CircleShape).background(AvColors[Math.abs(name.hashCode()) % AvColors.size]), Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(name.split(" ").mapNotNull { it.firstOrNull() }.take(2).joinToString("").uppercase().ifEmpty { "#" }, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable fun Dialer(contacts: List<Contact>, initial: String, onCall: (String) -> Unit) {
    var n by remember { mutableStateOf(initial) }
    val ctx = LocalContext.current
    val match = if (n.length > 2) contacts.firstOrNull { norm(it.number).contains(n) }?.name else null
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(n, fontSize = 38.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center, modifier = Modifier.heightIn(min = 56.dp))
        Text(match ?: "", color = Cyan, modifier = Modifier.height(24.dp))
        Spacer(Modifier.height(16.dp))
        "123456789*0#".chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                row.forEach { k ->
                    Box(Modifier.size(76.dp).clip(CircleShape).background(Card).border(1.dp, Color(0x1AFFFFFF), CircleShape).clickable { n += k }, Alignment.Center) {
                        Text(k.toString(), fontSize = 28.sp)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(28.dp), modifier = Modifier.padding(top = 12.dp)) {
            IconButton({ placeVoicemail(ctx) }, Modifier.size(48.dp)) { Icon(Icons.Filled.Voicemail, "Voicemail", tint = Mute) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(Green).clickable { if (n.isNotEmpty()) onCall(n) }, Alignment.Center) {
                Icon(Icons.Filled.Call, "Call", tint = Color.White, modifier = Modifier.size(30.dp))
            }
            IconButton({ n = n.dropLast(1) }, Modifier.size(48.dp)) { Icon(Icons.Filled.Backspace, "Delete", tint = Mute) }
        }
    }
}

@Composable fun Contacts(all: List<Contact>, onCall: (String) -> Unit, onMsg: (String) -> Unit, onEdit: (String) -> Unit, onAdd: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val groups = all.filter { it.name.contains(q, true) || it.number.contains(q) }.groupBy { it.name.firstOrNull()?.uppercaseChar() ?: '#' }
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Contacts", fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onAdd) { Icon(Icons.Filled.PersonAdd, "Add contact", tint = Cyan) }
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search contacts") }, singleLine = true, shape = RoundedCornerShape(16.dp))
        LazyColumn {
            groups.forEach { (l, list) ->
                item { Text(l.toString(), color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)) }
                items(list) { c ->
                    Row(Modifier.fillMaxWidth().clickable { onCall(c.number) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name)
                        Column(Modifier.weight(1f).padding(horizontal = 13.dp)) { Text(c.name, fontWeight = FontWeight.SemiBold); Text(c.number, color = Mute, fontSize = 14.sp) }
                        IconButton({ onEdit(c.id) }) { Icon(Icons.Filled.Edit, "Edit", tint = Mute) }
                        IconButton({ onMsg(c.number) }) { Icon(Icons.Filled.Email, "Message", tint = Cyan) }
                    }
                }
            }
        }
    }
}

@Composable fun Threads(sms: List<Sms>, nameOf: (String) -> String, open: (String) -> Unit) {
    val threads = sms.groupBy { norm(it.address) }.values.map { it.first() }
    var showNew by remember { mutableStateOf(false) }
    var newNum by remember { mutableStateOf("") }
    if (showNew) AlertDialog(onDismissRequest = { showNew = false },
        title = { Text("New message") },
        text = { OutlinedTextField(newNum, { newNum = it }, placeholder = { Text("Phone number") }, singleLine = true) },
        confirmButton = { TextButton({ if (newNum.isNotBlank()) { open(newNum.trim()); showNew = false; newNum = "" } }) { Text("Start") } },
        dismissButton = { TextButton({ showNew = false }) { Text("Cancel") } })
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Messages", fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ showNew = true }) { Icon(Icons.Filled.Edit, "New message", tint = Cyan) }
        }
        if (threads.isEmpty()) Text("No messages (or permission not granted)", color = Mute)
        LazyColumn { items(threads) { m ->
            Row(Modifier.fillMaxWidth().clickable { open(m.address) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(nameOf(m.address))
                Column(Modifier.padding(start = 13.dp)) {
                    Text(nameOf(m.address), fontWeight = FontWeight.SemiBold)
                    Text((if (m.out) "You: " else "") + m.body, color = Mute, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        } }
    }
}

@Composable fun Chat(name: String, msgs: List<Sms>, onBack: () -> Unit, onSend: (String) -> Unit) {
    var t by remember { mutableStateOf("") }
    val st = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) st.scrollToItem(msgs.lastIndex) }
    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
            Avatar(name, 40); Text(name, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 14.dp), st, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), if (m.out) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.body, Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(20.dp))
                        .background(if (m.out) Grad else Brush.linearGradient(listOf(Card, Card))).padding(14.dp, 10.dp))
                }
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Message") }, shape = RoundedCornerShape(26.dp), maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(50.dp).clip(CircleShape).background(Grad).clickable { if (t.isNotBlank()) { onSend(t.trim()); t = "" } }, Alignment.Center) {
                Icon(Icons.Filled.Send, "Send", tint = Color.White)
            }
        }
    }
}


@Composable fun Recents(calls: List<CallEntry>, nameOf: (String) -> String, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Recents", fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ ctx.getSystemService(TelecomManager::class.java).createManageBlockedNumbersIntent()?.let { ctx.startActivity(it) } }) { Icon(Icons.Filled.Block, "Blocked numbers", tint = Cyan) }
        }
        if (calls.isEmpty()) Text("No calls yet (or permission not granted)", color = Mute)
        LazyColumn { items(calls) { c ->
            val missed = c.type == CallLog.Calls.MISSED_TYPE
            Row(Modifier.fillMaxWidth().clickable { onCall(c.number) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(nameOf(c.number))
                Column(Modifier.weight(1f).padding(horizontal = 13.dp)) {
                    Text(nameOf(c.number), fontWeight = FontWeight.SemiBold, color = if (missed) Color(0xFFF43F5E) else Color.Unspecified)
                    Text(DateUtils.getRelativeTimeSpanString(c.date).toString(), color = Mute, fontSize = 14.sp)
                }
                Icon(when (c.type) { CallLog.Calls.INCOMING_TYPE -> Icons.Filled.CallReceived; CallLog.Calls.OUTGOING_TYPE -> Icons.Filled.CallMade; else -> Icons.Filled.CallMissed }, null, tint = Mute)
                IconButton({ blockNumber(ctx, c.number) }) { Icon(Icons.Filled.Block, "Block", tint = Mute) }
            }
        } }
    }
}

fun blockNumber(c: Context, n: String) {
    val ok = try {
        c.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, ContentValues().apply {
            put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n)
        }) != null
    } catch (e: Exception) { false }
    Toast.makeText(c, if (ok) "Blocked $n" else "Set Pulse as the default Phone app to block numbers", Toast.LENGTH_LONG).show()
}

fun placeVoicemail(c: Context) {
    val ok = ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
    try { c.startActivity(Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("voicemail:"))) }
    catch (e: Exception) { Toast.makeText(c, "Voicemail not available on this SIM", Toast.LENGTH_SHORT).show() }
}
