package com.pulse.phone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object CallState {
    var call by mutableStateOf<Call?>(null)
    var state by mutableIntStateOf(Call.STATE_NEW)
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var service: InCallService? = null
}

class PulseInCallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) { CallState.state = state }
    }
    override fun onCallAdded(call: Call) {
        call.registerCallback(cb)
        CallState.call = call; CallState.state = call.state; CallState.service = this
        CallState.muted = false; CallState.speaker = false
        val ui = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("calls", "Calls", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, ui, PendingIntent.FLAG_IMMUTABLE)
        nm.notify(1, Notification.Builder(this, "calls").setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Pulse call").setContentIntent(pi).setFullScreenIntent(pi, true)
            .setOngoing(true).setCategory(Notification.CATEGORY_CALL).build())
        try { startActivity(ui) } catch (e: Exception) {}
    }
    override fun onCallRemoved(call: Call) {
        call.unregisterCallback(cb)
        if (CallState.call == call) CallState.call = null
        getSystemService(NotificationManager::class.java).cancel(1)
    }
}

class InCallActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple)) { InCallScreen { finish() } } }
    }
}

@Composable fun RoundBtn(bg: Color, icon: ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(72.dp).clip(CircleShape).background(bg).clickable { onClick() }, Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(30.dp))
    }
}

@Composable fun InCallScreen(done: () -> Unit) {
    val ctx = LocalContext.current
    val call = CallState.call
    LaunchedEffect(call) { if (call == null) done() }
    val number = call?.details?.handle?.schemeSpecificPart ?: ""
    val name = remember(number) { loadContacts(ctx).firstOrNull { norm(it.number) == norm(number) }?.name ?: number.ifEmpty { "Unknown" } }
    val status = when (CallState.state) {
        Call.STATE_RINGING -> "Incoming call…"; Call.STATE_ACTIVE -> "Connected"
        Call.STATE_HOLDING -> "On hold"; else -> "Calling…"
    }
    val glass = Color(0x33FFFFFF)
    Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1B1146), Color(0xFF0A3A4A)))).padding(32.dp),
        verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.padding(top = 80.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(name, 120); Spacer(Modifier.height(24.dp))
            Text(name, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(status, color = Cyan)
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 60.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            if (CallState.state == Call.STATE_RINGING) {
                RoundBtn(Color(0xFFEF4444), Icons.Filled.CallEnd) { call?.reject(false, null) }
                RoundBtn(Green, Icons.Filled.Call) { call?.answer(VideoProfile.STATE_AUDIO_ONLY) }
            } else {
                RoundBtn(if (CallState.muted) Purple else glass, if (CallState.muted) Icons.Filled.MicOff else Icons.Filled.Mic) {
                    CallState.muted = !CallState.muted; CallState.service?.setMuted(CallState.muted)
                }
                RoundBtn(Color(0xFFEF4444), Icons.Filled.CallEnd) { call?.disconnect() }
                RoundBtn(if (CallState.speaker) Purple else glass, Icons.Filled.VolumeUp) {
                    CallState.speaker = !CallState.speaker
                    CallState.service?.setAudioRoute(if (CallState.speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
                }
            }
        }
    }
}
