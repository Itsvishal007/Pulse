package com.pulse.phone

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val ms = Telephony.Sms.Intents.getMessagesFromIntent(i)
        if (ms.isNullOrEmpty()) return
        val from = ms[0].originatingAddress ?: return
        val body = ms.joinToString("") { it.messageBody ?: "" }
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
            put("address", from); put("body", body); put("date", System.currentTimeMillis()); put("read", 0)
        })
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("sms", "Messages", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(from.hashCode(), Notification.Builder(c, "sms").setSmallIcon(android.R.drawable.sym_action_email)
                .setContentTitle(from).setContentText(body).setContentIntent(pi).setAutoCancel(true).build())
        } catch (e: Exception) {}
    }
}

class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class RespondService : Service() { override fun onBind(i: Intent?): IBinder? = null }
